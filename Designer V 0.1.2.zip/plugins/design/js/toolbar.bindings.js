/* global document, DesignBlocks */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);

  function initToolbar(host = document) {
    const btnAdd = $("#add-root", host);
    const btnChild = $("#add-child", host);
    const btnDup = $("#dup", host);
    const btnDel = $("#del", host);
    const selLabel = $("#selLabel", host);

    if (!btnAdd && !btnChild && !btnDup && !btnDel) {
      console.warn("[DesignToolbar] тулбар не знайдено у host:", host);
      return () => {};
    }

    btnAdd && btnAdd.addEventListener("click", () => DesignBlocks.addRoot());
    btnChild &&
      btnChild.addEventListener("click", () => DesignBlocks.addChild());
    btnDup && btnDup.addEventListener("click", () => DesignBlocks.duplicate());
    btnDel &&
      btnDel.addEventListener("click", () => DesignBlocks.removeSelected());

    const onKey = (e) => {
      if (
        (e.key === "Delete" || e.key === "Backspace") &&
        !["INPUT", "TEXTAREA", "SELECT"].includes(
          document.activeElement?.tagName || ""
        )
      ) {
        e.preventDefault();
        DesignBlocks.removeSelected();
      }
    };
    document.addEventListener("keydown", onKey);

    DesignBlocks.onChange(({ selectedId }) => {
      if (selLabel)
        selLabel.textContent = selectedId
          ? `ID: ${selectedId}`
          : "Немає вибору";
    });

    console.log("[DesignToolbar] bound to buttons");
    return () => document.removeEventListener("keydown", onKey);
  }

  window.DesignToolbar = { initToolbar };
})();
