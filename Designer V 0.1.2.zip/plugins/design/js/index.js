console.log("[design] index.js loaded");

(async () => {
  // чекаємо, поки зʼявляться слоти (на випадок асинхронного рендера)
  function waitFor(sel, root = document, timeout = 5000) {
    const el = root.querySelector(sel);
    if (el) return Promise.resolve(el);
    return new Promise((resolve, reject) => {
      const mo = new MutationObserver(() => {
        const n = root.querySelector(sel);
        if (n) {
          mo.disconnect();
          resolve(n);
        }
      });
      mo.observe(root === document ? document.documentElement : root, {
        childList: true,
        subtree: true,
      });
      setTimeout(() => {
        mo.disconnect();
        reject(new Error("timeout " + sel));
      }, timeout);
    });
  }

  await waitFor(".st-app");
  await waitFor("#right");
  await waitFor("#left");

  const api = await window.InspectorWindow.init({
    rightSlotSel: "#right",
    leftSlotSel: "#left",
    appSel: ".st-app",
    toolbarSel: ".toolbar",
    htmlUrl: "plugins/design/assets/inspector.html",
  });

  console.log("[design] inspector mounted", api);
})();

// десь після того, як inspector.html уже в DOM (#right або #left)
(function initBindingsWhenReady() {
  // невеликий “waitFor”, щоб не промахнутись по таймінгу
  const waitFor = (sel, root = document, t = 7000) =>
    new Promise((res, rej) => {
      const el = root.querySelector(sel);
      if (el) return res(el);
      const mo = new MutationObserver(() => {
        const e = root.querySelector(sel);
        if (e) {
          mo.disconnect();
          res(e);
        }
      });
      mo.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => {
        mo.disconnect();
        rej(new Error("timeout " + sel));
      }, t);
    });

  waitFor("#right .panel, #left .panel")
    .then((root) => {
      // ініт прив’язок; якщо ти клав файл як я радив — глобальне API є тут:
      if (
        window.InspectorBindings &&
        typeof window.InspectorBindings.init === "function"
      ) {
        window.InspectorBindings.init(
          root.closest("#right") || root.closest("#left") || document
        );
        console.log("[design] inspector bindings init");
      } else {
        console.warn(
          "[design] InspectorBindings not found — підключи plugins/design/js/inspector.bindings.js"
        );
      }
    })
    .catch(console.warn);
})();

/* index.js — головний вхід плагіна "Дизайн" */
(async () => {
  const log = (...a) => console.log("[design]", ...a);
  const err = (...a) => console.error("[design]", ...a);

  // допоміжне: довантажити скрипт, якщо його ще нема
  function has(g) {
    return !!g;
  }
  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement("script");
      s.src = src;
      s.async = true;
      s.onload = () => res(src);
      s.onerror = () => rej(new Error("Failed to load " + src));
      document.head.appendChild(s);
    });
  }

  log("index.js loaded");

  // 1) переконаймося, що DOM готовий
  if (document.readyState === "loading") {
    await new Promise((r) =>
      document.addEventListener("DOMContentLoaded", r, { once: true })
    );
  }

  // 2) знайдемо хост та канвас
  const host = document.querySelector(".st-app") || document;
  const canvas =
    host.querySelector("#canvas") || document.querySelector("#canvas");
  if (!canvas) {
    err(
      'Не знайдено #canvas. Має бути: <div class="canvas" id="canvas"></div>'
    );
    return;
  }

  // 3) довантажуємо ядро, якщо потрібно
  if (!window.DesignBlocks) {
    try {
      await loadScript("plugins/design/js/blocks.core.js"); // підстав свій шлях, якщо інший
      log("blocks.core.js loaded");
    } catch (e) {
      err("blocks.core.js 404?", e);
      return;
    }
  }

  // 4) довантажуємо биндинги тулбара, якщо потрібно
  if (!window.DesignToolbar) {
    try {
      await loadScript("plugins/design/js/toolbar.bindings.js");
      log("toolbar.bindings.js loaded");
    } catch (e) {
      err("toolbar.bindings.js 404?", e);
      // не фатально: нижче зробимо прямі обробники
    }
  }

  // 5) монтуємо ядро
  try {
    window.DesignBlocks.mount(host);
    log("blocks mounted →", window.DesignBlocks?.state?.canvas);
  } catch (e) {
    err("DesignBlocks.mount() впав:", e);
    return;
  }

  // 6) чіпляємо тулбар
  if (window.DesignToolbar?.initToolbar) {
    window.DesignToolbar.initToolbar(host);
    log("toolbar bound via DesignToolbar");
  } else {
    // fallback: прямі обробники на кнопки
    const $ = (sel, root = document) => root.querySelector(sel);
    $("#add-root", host)?.addEventListener("click", () =>
      window.DesignBlocks.addRoot()
    );
    $("#add-child", host)?.addEventListener("click", () =>
      window.DesignBlocks.addChild()
    );
    $("#dup", host)?.addEventListener("click", () =>
      window.DesignBlocks.duplicate()
    );
    $("#del", host)?.addEventListener("click", () =>
      window.DesignBlocks.removeSelected()
    );
    document.addEventListener("keydown", (e) => {
      if (
        (e.key === "Delete" || e.key === "Backspace") &&
        !["INPUT", "TEXTAREA", "SELECT"].includes(
          document.activeElement?.tagName || ""
        )
      ) {
        e.preventDefault();
        window.DesignBlocks.removeSelected();
      }
    });
    log("toolbar bound (fallback)");
  }

  // 7) щоб точно побачити дію — один демо-блок, якщо порожньо
  if (!window.DesignBlocks.state.rootBlocks?.length) {
    window.DesignBlocks.addRoot();
  }
})();
