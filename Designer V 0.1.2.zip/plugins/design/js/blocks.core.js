/* global document */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const uid = () => Math.random().toString(36).slice(2, 9);

  const state = {
    host: null,
    canvas: null,
    rootBlocks: [],
    selectedId: null,
    listeners: new Set(),
  };

  // модель
  const createBlock = (partial = {}) =>
    Object.assign(
      {
        id: uid(),
        display: "flex",
        dir: "column",
        children: [],
      },
      partial
    );

  // пошук
  function findById(list, id) {
    for (const b of list) {
      if (b.id === id) return b;
      const stack = [...b.children];
      while (stack.length) {
        const n = stack.shift();
        if (n.id === id) return n;
        stack.push(...n.children);
      }
    }
    return null;
  }
  function findParentAndIndex(id, list = state.rootBlocks) {
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      if (b.id === id) return { parent: null, arr: list, index: i };
      const r = deep(b, id);
      if (r) return r;
    }
    return null;
  }
  function deep(node, id) {
    for (let i = 0; i < node.children.length; i++) {
      const c = node.children[i];
      if (c.id === id) return { parent: node, arr: node.children, index: i };
      const r = deep(c, id);
      if (r) return r;
    }
    return null;
  }

  // рендер (простий, щоб бачити результат)
  function renderBlock(b) {
    const el = document.createElement("div");
    el.className = "st-block";
    el.dataset.id = b.id;
    el.textContent = `Block ${b.id.slice(0, 4)} (${b.dir})`;
    if (b.id === state.selectedId) el.classList.add("selected");
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      api.select(b.id);
    });
    b.children.forEach((c) => el.appendChild(renderBlock(c)));
    return el;
  }

  function render() {
    if (!state.canvas) return;
    state.canvas.innerHTML = "";
    state.rootBlocks.forEach((b) => state.canvas.appendChild(renderBlock(b)));
    emit();
  }

  // дії
  function addRoot() {
    const b = createBlock();
    state.rootBlocks.push(b);
    state.selectedId = b.id;
    render();
  }
  function addChild() {
    const sel = findById(state.rootBlocks, state.selectedId);
    if (!sel) return;
    const ch = createBlock({ dir: "column" });
    sel.children.push(ch);
    state.selectedId = ch.id;
    render();
  }
  function duplicate() {
    const pos = findParentAndIndex(state.selectedId);
    if (!pos) return;
    const original = pos.arr[pos.index];
    const copy = JSON.parse(JSON.stringify(original));
    copy.id = uid();
    pos.arr.splice(pos.index + 1, 0, copy);
    state.selectedId = copy.id;
    render();
  }
  function removeSelected() {
    const pos = findParentAndIndex(state.selectedId);
    if (!pos) return;
    pos.arr.splice(pos.index, 1);
    state.selectedId = null;
    render();
  }
  function select(id) {
    state.selectedId = id;
    render();
  }

  // події
  function onChange(cb) {
    state.listeners.add(cb);
  }
  function offChange(cb) {
    state.listeners.delete(cb);
  }
  function emit() {
    state.listeners.forEach((cb) => {
      try {
        cb({ ...state });
      } catch {}
    });
  }

  const api = {
    mount(host = document) {
      state.host = host;
      // шукаємо саме той canvas, що у твоєму макеті
      state.canvas =
        host.querySelector("#canvas") || document.querySelector("#canvas");
      if (!state.canvas) {
        console.error(
          '[DesignBlocks] #canvas не знайдено. Переконайся, що є <div class="canvas" id="canvas"></div>.'
        );
        return api;
      }
      // демо — щоб було що бачити
      if (state.rootBlocks.length === 0) {
        const root = createBlock({ dir: "row" });
        root.children.push(createBlock());
        root.children.push(createBlock());
        state.rootBlocks = [root];
        state.selectedId = root.id;
      }
      render();
      console.log("[DesignBlocks] mounted, canvas =", state.canvas);
      return api;
    },
    unmount() {
      state.host = null;
      state.canvas = null;
      state.rootBlocks = [];
      state.selectedId = null;
      state.listeners.clear();
    },
    addRoot,
    addChild,
    duplicate,
    removeSelected,
    select,
    get state() {
      return state;
    },
    onChange,
    offChange,
    render,
  };

  window.DesignBlocks = api;
})();
