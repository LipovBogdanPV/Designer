// ПІДВ’ЯЗКА ІНСПЕКТОРА ДО DesignBlocks
// Підключай ПІСЛЯ blocks.core.js і ПІСЛЯ підключення/рендера inspector.html у #right/#left

(function (global) {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // ---- утиліти
  const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));
  const hexToRgba = (hex, a = 1) => {
    if (!hex) return `rgba(0,0,0,${a})`;
    let c = hex.replace("#", "");
    if (c.length === 3)
      c = c
        .split("")
        .map((x) => x + x)
        .join("");
    const v = parseInt(c, 16);
    return `rgba(${(v >> 16) & 255},${(v >> 8) & 255},${v & 255},${a})`;
  };

  // Тоггл видимих підсекцій у формі
  function show(id, on = true) {
    const el = $(id);
    if (!el) return;
    el.style.display = on ? "" : "none";
  }

  function ensurePath(obj, path, fallback) {
    let cur = obj;
    for (const k of path) {
      if (cur[k] == null)
        cur[k] =
          typeof fallback === "function"
            ? fallback()
            : Array.isArray(fallback)
            ? []
            : {};
      cur = cur[k];
    }
    return cur;
  }

  // ---- Прив’язка
  function initInspectorBindings(host = document) {
    const api = global.DesignBlocks;
    if (!api) {
      console.warn("[inspector] DesignBlocks not found");
      return;
    }

    // Кеш контролів
    const C = {
      // Розмітка
      display: $("#display", host),
      dir: $("#dir", host),
      justify: $("#justify", host),
      align: $("#align", host),
      gap: $("#gap", host),
      padT: $("#padT", host),
      padR: $("#padR", host),
      padB: $("#padB", host),
      padL: $("#padL", host),
      maxw: $("#maxw", host),

      // Розмір & розподіл
      sizeMode: $("#sizeMode", host),
      sizeVal: $("#sizeVal", host),
      grow: $("#grow", host),
      shrink: $("#shrink", host),
      alignSelf: $("#alignSelf", host),
      minH: $("#minH", host),
      widthPx: $("#widthPx", host),
      fullHeight: $("#fullHeight", host),
      fixedHeight: $("#fixedHeight", host),
      dockWhere: $("#dockWhere", host),
      dockWidth: $("#dockWidth", host),
      presets: $$(".templates [data-preset]", host),

      // Заливка
      bgType: $("#bgType", host),
      bgColor: $("#bgColor", host),
      bgAlpha: $("#bgAlpha", host),

      gA: $("#gA", host),
      gAalpha: $("#gAalpha", host),
      gB: $("#gB", host),
      gBalpha: $("#gBalpha", host),
      gAngle: $("#gAngle", host),

      bgUrl: $("#bgUrl", host),
      bgSize: $("#bgSize", host),
      bgPos: $("#bgPos", host),
      bgOverlayColor: $("#bgOverlayColor", host),
      bgOverlayAlpha: $("#bgOverlayAlpha", host),
      bgGray: $("#bgGray", host),

      // секції для видимості
      bgColorRows: $("#bgColorRows", host),
      bgGradRows: $("#bgGradRows", host),
      bgImgRows: $("#bgImgRows", host),

      // Кути / Бордер
      cornerMode: $("#cornerMode", host),
      radiusMode: $("#radiusMode", host),

      rAllVal: $("#rAllVal", host),
      rTL: $("#rTL", host),
      rTR: $("#rTR", host),
      rBL: $("#rBL", host),
      rBR: $("#rBR", host),
      rD1A: $("#rD1A", host),
      rD1B: $("#rD1B", host),
      rD2A: $("#rD2A", host),
      rD2B: $("#rD2B", host),

      roundedBox: $("#roundedBox", host),
      chamferBox: $("#chamferBox", host),
      polygonBox: $("#polygonBox", host),

      bWidth: $("#bWidth", host),
      bStyle: $("#bStyle", host),
      bColor: $("#bColor", host),
      bAlpha: $("#bAlpha", host),
      bBlur: $("#bBlur", host),
    };

    // ------ APPLY helpers
    const upd = (fnOrPatch) => api.updateSelected(fnOrPatch);

    // Перемикання видимих секцій фону
    function reflectBgType(type) {
      show("#bgColorRows", type === "color");
      show("#bgGradRows", type === "gradient");
      show("#bgImgRows", type === "image");
    }

    // Перемикання боксів радіусів залежно від режиму форми
    function reflectCornerMode(mode, rMode) {
      show("#roundedBox", mode === "rounded");
      show("#chamferBox", mode === "chamfer");
      show("#polygonBox", mode === "polygon");
      // для rounded додатково показати підрежими
      show("#rAll", mode === "rounded" && rMode === "all");
      show("#rPer", mode === "rounded" && rMode === "per");
      show("#rDiag1", mode === "rounded" && rMode === "diag1");
      show("#rDiag2", mode === "rounded" && rMode === "diag2");
    }

    // ---- WRITE: BINDINGS
    // 1) Розмітка секції
    C.display?.addEventListener("change", () =>
      upd((b) => {
        b.display = C.display.value;
      })
    );
    C.dir?.addEventListener("change", () =>
      upd((b) => {
        b.dir = C.dir.value;
      })
    );
    C.justify?.addEventListener("change", () =>
      upd((b) => {
        b.justify = C.justify.value;
      })
    );
    C.align?.addEventListener("change", () =>
      upd((b) => {
        b.align = C.align.value;
      })
    );
    C.gap?.addEventListener("input", () =>
      upd((b) => {
        b.gap = clamp(C.gap.value, 0, 128);
      })
    );

    ["padT", "padR", "padB", "padL"].forEach((k) => {
      C[k]?.addEventListener("input", () =>
        upd((b) => {
          ensurePath(b, ["padding"]);
          b.padding.t = +C.padT.value || 0;
          b.padding.r = +C.padR.value || 0;
          b.padding.b = +C.padB.value || 0;
          b.padding.l = +C.padL.value || 0;
        })
      );
    });

    C.maxw?.addEventListener("change", () =>
      upd((b) => {
        b.maxWidth = C.maxw.value || "";
      })
    );

    // 2) Розмір & розподіл
    C.sizeMode?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["layout", "basis"]);
        b.layout.basis.mode = C.sizeMode.value; // auto|fill|px|%
        if (b.layout.basis.mode === "fill") {
          b.layout.basis.value = 0;
          b.layout.grow = 1;
          b.layout.shrink = 1;
        }
      })
    );
    C.sizeVal?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["layout", "basis"]);
        b.layout.basis.value = +C.sizeVal.value || 0;
      })
    );
    C.grow?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.grow = C.grow.checked ? 1 : 0;
      })
    );
    C.shrink?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.shrink = C.shrink.checked ? 1 : 0;
      })
    );
    C.alignSelf?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.alignSelf = C.alignSelf.value;
      })
    );
    C.minH?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.minHeightPx = +C.minH.value || 0;
      })
    );
    C.widthPx?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.widthPx = +C.widthPx.value || 0;
      })
    );
    C.fullHeight?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.fullHeight = !!C.fullHeight.checked;
        if (b.layout.fullHeight) b.layout.fixedHeight = "";
      })
    );
    C.fixedHeight?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["layout"]);
        b.layout.fixedHeight = C.fixedHeight.value || "";
        if (b.layout.fixedHeight) b.layout.fullHeight = false;
      })
    );
    C.dockWhere?.addEventListener("change", () =>
      upd((b) => {
        /* це лише для пресетів 2-колонки — залиш як «hint» */
      })
    );
    C.dockWidth?.addEventListener("input", () =>
      upd((b) => {
        /* те саме — використовуй у своїх шаблонах */
      })
    );
    C.presets?.forEach((btn) => {
      btn.addEventListener("click", () => {
        const p = btn.dataset.preset; // XS,S,M,L,XL,XXL
        const map = { XS: 720, S: 860, M: 1024, L: 1280, XL: 1440, XXL: 1680 };
        const v = map[p] || "";
        upd((b) => {
          b.maxWidth = v ? `${v}px` : "";
        });
        if (C.maxw) C.maxw.value = v ? `${v}px` : "";
      });
    });

    // 3) Заливка секції
    C.bgType?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.type = C.bgType.value; // none|color|gradient|image
        reflectBgType(b.style.bg.type);
      })
    );

    // color
    C.bgColor?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.color = C.bgColor.value;
      })
    );
    C.bgAlpha?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.alpha = +C.bgAlpha.value || 0;
      })
    );

    // gradient
    C.gA?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.gA = C.gA.value;
      })
    );
    C.gAalpha?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.gAalpha = +C.gAalpha.value || 0;
      })
    );
    C.gB?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.gB = C.gB.value;
      })
    );
    C.gBalpha?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.gBalpha = +C.gBalpha.value || 0;
      })
    );
    C.gAngle?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.angle = +C.gAngle.value || 0;
      })
    );

    // image
    C.bgUrl?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.url = C.bgUrl.value.trim();
      })
    );
    C.bgSize?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.size = C.bgSize.value;
      })
    );
    C.bgPos?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.pos = C.bgPos.value;
      })
    );
    C.bgOverlayColor?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.overlayColor = C.bgOverlayColor.value;
      })
    );
    C.bgOverlayAlpha?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.overlayAlpha = +C.bgOverlayAlpha.value || 0;
      })
    );
    C.bgGray?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "bg"]);
        b.style.bg.gray = +C.bgGray.value || 0;
      })
    );

    // 4) Кути / Бордер
    C.cornerMode?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.mode =
          C.cornerMode.value === "rounded"
            ? b.style.radius.mode || "all"
            : b.style.radius.mode || "all";
        // для chamfer/polygon — поки що візуальні місця тримаємо; геометрію можеш додати окремо
        reflectCornerMode(C.cornerMode.value, C.radiusMode?.value || "all");
      })
    );

    C.radiusMode?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.mode = C.radiusMode.value; // all|per|diag1|diag2
        reflectCornerMode("rounded", C.radiusMode.value);
      })
    );

    // rounded values
    C.rAllVal?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.all = +C.rAllVal.value || 0;
      })
    );
    C.rTL?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.tl = +C.rTL.value || 0;
      })
    );
    C.rTR?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.tr = +C.rTR.value || 0;
      })
    );
    C.rBL?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.bl = +C.rBL.value || 0;
      })
    );
    C.rBR?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.br = +C.rBR.value || 0;
      })
    );
    C.rD1A?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.d1a = +C.rD1A.value || 0;
      })
    );
    C.rD1B?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.d1b = +C.rD1B.value || 0;
      })
    );
    C.rD2A?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.d2a = +C.rD2A.value || 0;
      })
    );
    C.rD2B?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "radius"]);
        b.style.radius.d2b = +C.rD2B.value || 0;
      })
    );

    // border
    C.bWidth?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "border"]);
        b.style.border.width = +C.bWidth.value || 0;
      })
    );
    C.bStyle?.addEventListener("change", () =>
      upd((b) => {
        ensurePath(b, ["style", "border"]);
        b.style.border.style = C.bStyle.value;
      })
    );
    C.bColor?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "border"]);
        b.style.border.color = C.bColor.value;
      })
    );
    C.bAlpha?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "border"]);
        b.style.border.alpha = +C.bAlpha.value || 0;
      })
    );
    C.bBlur?.addEventListener("input", () =>
      upd((b) => {
        ensurePath(b, ["style", "border"]);
        b.style.border.soft = +C.bBlur.value || 0;
      })
    );

    // ---- READ: відображення в форму зі стану
    function reflectToForm() {
      const b = api.getSelected?.();
      // Якщо нема вибору — гречно вийти
      if (!b) return;

      // Розмітка
      if (C.display) C.display.value = b.display || "flex";
      if (C.dir) C.dir.value = b.dir || "column";
      if (C.justify) C.justify.value = b.justify || "flex-start";
      if (C.align) C.align.value = b.align || "stretch";
      if (C.gap) C.gap.value = b.gap ?? 16;

      const pad = b.padding || {};
      if (C.padT) C.padT.value = pad.t ?? 0;
      if (C.padR) C.padR.value = pad.r ?? 0;
      if (C.padB) C.padB.value = pad.b ?? 0;
      if (C.padL) C.padL.value = pad.l ?? 0;
      if (C.maxw) C.maxw.value = b.maxWidth || "";

      // Розмір
      const L = b.layout || {};
      const basis = L.basis || { mode: "auto", value: 0 };
      if (C.sizeMode) C.sizeMode.value = basis.mode || "auto";
      if (C.sizeVal) C.sizeVal.value = basis.value ?? "";
      if (C.grow) C.grow.checked = !!L.grow;
      if (C.shrink) C.shrink.checked = !!L.shrink;
      if (C.alignSelf) C.alignSelf.value = L.alignSelf || "auto";
      if (C.minH) C.minH.value = L.minHeightPx ?? "";
      if (C.widthPx) C.widthPx.value = L.widthPx ?? "";
      if (C.fullHeight) C.fullHeight.checked = !!L.fullHeight;
      if (C.fixedHeight) C.fixedHeight.value = L.fixedHeight || "";

      // Заливка
      const bg = (b.style && b.style.bg) || {};
      if (C.bgType) {
        C.bgType.value = bg.type || "none";
        reflectBgType(C.bgType.value);
      }
      if (C.bgColor) C.bgColor.value = bg.color || "#111827";
      if (C.bgAlpha) C.bgAlpha.value = bg.alpha ?? 1;

      if (C.gA) C.gA.value = bg.gA || "#0ea5e9";
      if (C.gAalpha) C.gAalpha.value = bg.gAalpha ?? 1;
      if (C.gB) C.gB.value = bg.gB || "#1d4ed8";
      if (C.gBalpha) C.gBalpha.value = bg.gBalpha ?? 1;
      if (C.gAngle) C.gAngle.value = bg.angle ?? 135;

      if (C.bgUrl) C.bgUrl.value = bg.url || "";
      if (C.bgSize) C.bgSize.value = bg.size || "cover";
      if (C.bgPos) C.bgPos.value = bg.pos || "center";
      if (C.bgOverlayColor)
        C.bgOverlayColor.value = bg.overlayColor || "#000000";
      if (C.bgOverlayAlpha) C.bgOverlayAlpha.value = bg.overlayAlpha ?? 0.35;
      if (C.bgGray) C.bgGray.value = bg.gray ?? 0;

      // Кути/бордер
      const r = (b.style && b.style.radius) || {
        mode: "all",
        all: 16,
        tl: 16,
        tr: 16,
        bl: 16,
        br: 16,
        d1a: 24,
        d1b: 8,
        d2a: 24,
        d2b: 8,
      };
      const cornerMode = "rounded"; // розшириш пізніше, якщо треба chamfer/polygon
      if (C.cornerMode) C.cornerMode.value = cornerMode;
      if (C.radiusMode) C.radiusMode.value = r.mode || "all";
      reflectCornerMode(cornerMode, r.mode || "all");

      if (C.rAllVal) C.rAllVal.value = r.all ?? 0;
      if (C.rTL) C.rTL.value = r.tl ?? 0;
      if (C.rTR) C.rTR.value = r.tr ?? 0;
      if (C.rBL) C.rBL.value = r.bl ?? 0;
      if (C.rBR) C.rBR.value = r.br ?? 0;
      if (C.rD1A) C.rD1A.value = r.d1a ?? 0;
      if (C.rD1B) C.rD1B.value = r.d1b ?? 0;
      if (C.rD2A) C.rD2A.value = r.d2a ?? 0;
      if (C.rD2B) C.rD2B.value = r.d2b ?? 0;

      const bd = (b.style && b.style.border) || {};
      if (C.bWidth) C.bWidth.value = bd.width ?? 0;
      if (C.bStyle) C.bStyle.value = bd.style || "solid";
      if (C.bColor) C.bColor.value = bd.color || "#334155";
      if (C.bAlpha) C.bAlpha.value = bd.alpha ?? 1;
      if (C.bBlur) C.bBlur.value = bd.soft ?? 0;
    }

    // ініціал відображення
    reflectToForm();

    // оновлюємо форму, коли міняється вибір
    api.onSelectionChange?.(reflectToForm);
    // якщо ядро має onStateChange — теж корисно рефрешнути форму (щоб слайдери не відставали)
    api.onStateChange?.(reflectToForm);

    console.log("[inspector] bindings attached");
  }

  // експорт
  global.InspectorBindings = { init: initInspectorBindings };
})(window);
