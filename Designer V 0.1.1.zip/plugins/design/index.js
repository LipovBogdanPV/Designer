(function () {
  // ===== helpers
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const uid = () => Math.random().toString(36).slice(2, 9);
  const clamp = (n, min, max) => Math.max(min, Math.min(max, Number(n) || 0));
  const hexToRgba = (hex, alpha = 1) => {
    if (!hex) return `rgba(0,0,0,${alpha})`;
    let c = hex.replace("#", "");
    if (c.length === 3) {
      c = c
        .split("")
        .map((x) => x + x)
        .join("");
    }
    const v = parseInt(c, 16);
    const r = (v >> 16) & 255,
      g = (v >> 8) & 255,
      b = v & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  };

  // ===== Data
  function createBlock(partial = {}) {
    return Object.assign(
      {
        id: uid(),
        display: "flex", // 'flex' | 'grid'
        dir: "column", // flex only
        grid: { cols: 2, gap: 16 }, // grid only
        justify: "flex-start",
        align: "stretch",
        gap: 16,
        padding: { t: 24, r: 24, b: 24, l: 24 },
        maxWidth: "",
        layout: {
          basis: { mode: "auto", value: 0, unit: "px" }, // auto|px|%|fill
          grow: 0,
          shrink: 1,
          alignSelf: "auto",
          widthPx: "",
          minHeightPx: 0,
          fullHeight: false,
          fixedHeight: "", // NEW
        },
        style: {
          bg: {
            type: "none",
            color: "#1f2937",
            alpha: 1,
            gA: "#0ea5e9",
            gAalpha: 1,
            gB: "#1d4ed8",
            gBalpha: 1,
            angle: 135,
            url: "",
            size: "cover",
            pos: "center",
            overlayColor: "#0f172a",
            overlayAlpha: 0.35,
            gray: 0,
          },
          radius: {
            mode: "all",
            all: 16,
            tl: 16,
            tr: 16,
            br: 16,
            bl: 16,
            d1a: 24,
            d1b: 8,
            d2a: 24,
            d2b: 8,
          },
          border: {
            width: 1,
            style: "solid",
            color: "#334155",
            alpha: 0.4,
            soft: 6,
          },
          shadow: {
            x: 0,
            y: 8,
            blur: 24,
            spread: 0,
            color: "#000000",
            alpha: 0.25,
            inset: {
              x: 0,
              y: 0,
              blur: 0,
              spread: 0,
              color: "#000000",
              alpha: 0,
            },
          },
          overlay: {
            top: { enable: false, color: "#000000", alpha: 0.4, h: 120 },
            bottom: { enable: false, color: "#000000", alpha: 0.4, h: 120 },
          },
        },
        scroll: {
          x: false,
          y: false,
          panEnable: false,
          panDir: "y",
          bgFixed: false,
        },
        children: [],
      },
      partial
    );
  }
  const cloneBlock = (b) => JSON.parse(JSON.stringify(b));
  const computeRadii = (r) => {
    if (r.mode === "all") return { tl: r.all, tr: r.all, br: r.all, bl: r.all };
    if (r.mode === "per") return { tl: r.tl, tr: r.tr, br: r.br, bl: r.bl };
    if (r.mode === "diag1")
      return { tl: r.d1a, br: r.d1a, tr: r.d1b, bl: r.d1b };
    if (r.mode === "diag2")
      return { tr: r.d2a, bl: r.d2a, tl: r.d2b, br: r.d2b };
    return { tl: 0, tr: 0, br: 0, bl: 0 };
  };
  function buildBackground(bg) {
    if (bg.type === "none") return "transparent";
    if (bg.type === "color") return hexToRgba(bg.color, bg.alpha);
    if (bg.type === "gradient") {
      const ca = hexToRgba(bg.gA, bg.gAalpha),
        cb = hexToRgba(bg.gB, bg.gBalpha);
      return `linear-gradient(${bg.angle}deg, ${ca}, ${cb})`;
    }
    if (bg.type === "image") {
      const ov =
        bg.overlayAlpha > 0
          ? `linear-gradient(${hexToRgba(
              bg.overlayColor,
              bg.overlayAlpha
            )}, ${hexToRgba(bg.overlayColor, bg.overlayAlpha)}), `
          : "";
      return `${ov}url('${bg.url}')`;
    }
    return "transparent";
  }

  // ===== State
  let host,
    canvas,
    rootBlocks = [],
    selectedId = null;

  // ===== Render
  function applyBlockStyles(el, b) {
    const s = b.style,
      r = computeRadii(s.radius);
    // display mode
    if (b.display === "grid") {
      el.style.display = "grid";
      el.style.gridTemplateColumns = `repeat(${Math.max(
        1,
        b.grid.cols || 2
      )}, minmax(0,1fr))`;
      el.style.gridGap = (b.grid.gap || 0) + "px";
      el.dataset.dir = "";
    } else {
      el.style.display = "flex";
      el.dataset.dir = b.dir;
      el.style.flexDirection = b.dir;
      el.style.justifyContent = b.justify;
      el.style.alignItems = b.align;
      el.style.gap = (b.gap || 0) + "px";
    }

    el.style.paddingTop = (b.padding.t || 0) + "px";
    el.style.paddingRight = (b.padding.r || 0) + "px";
    el.style.paddingBottom = (b.padding.b || 0) + "px";
    el.style.paddingLeft = (b.padding.l || 0) + "px";
    el.style.maxWidth = b.maxWidth || "";
    el.style.margin = b.maxWidth ? "0 auto" : "";

    // background (with img layer)
    const bgLayer = el.querySelector(":scope > .bg-layer");
    if (s.bg.type === "image") {
      el.style.background = "transparent";
      bgLayer.style.display = "block";
      bgLayer.style.background = buildBackground(s.bg);
      bgLayer.style.backgroundSize = s.bg.size;
      bgLayer.style.backgroundPosition = s.bg.pos;
      bgLayer.style.backgroundAttachment = b.scroll.bgFixed
        ? "fixed"
        : "scroll";
      bgLayer.style.filter = `grayscale(${s.bg.gray || 0})`;
    } else {
      bgLayer.style.display = "none";
      el.style.background = buildBackground(s.bg);
      el.style.backgroundSize = "";
      el.style.backgroundPosition = "";
      el.style.backgroundRepeat = "";
    }

    // radius
    el.style.borderTopLeftRadius = r.tl + "px";
    el.style.borderTopRightRadius = r.tr + "px";
    el.style.borderBottomRightRadius = r.br + "px";
    el.style.borderBottomLeftRadius = r.bl + "px";

    // border
    const bcol = hexToRgba(s.border.color, s.border.alpha);
    el.style.borderWidth = (s.border.width || 0) + "px";
    el.style.borderStyle = s.border.style;
    el.style.borderColor = s.border.width ? bcol : "transparent";

    // shadows
    const outer = `${s.shadow.x || 0}px ${s.shadow.y || 0}px ${
      s.shadow.blur || 0
    }px ${s.shadow.spread || 0}px ${hexToRgba(s.shadow.color, s.shadow.alpha)}`;
    const inner = `${s.shadow.inset.x || 0}px ${s.shadow.inset.y || 0}px ${
      s.shadow.inset.blur || 0
    }px ${s.shadow.inset.spread || 0}px ${hexToRgba(
      s.shadow.inset.color,
      s.shadow.inset.alpha
    )} inset`;
    const arr = [];
    if (
      (s.shadow.blur || 0) > 0 ||
      (s.shadow.spread || 0) !== 0 ||
      (s.shadow.x || 0) !== 0 ||
      (s.shadow.y || 0) !== 0 ||
      (s.shadow.alpha || 0) > 0
    )
      arr.push(outer);
    if (
      (s.shadow.inset.blur || 0) > 0 ||
      (s.shadow.inset.spread || 0) !== 0 ||
      (s.shadow.inset.x || 0) !== 0 ||
      (s.shadow.inset.y || 0) !== 0 ||
      (s.shadow.inset.alpha || 0) > 0
    )
      arr.push(inner);
    const soft = s.border.soft || 0;
    if (soft > 0 && s.border.width > 0) {
      arr.push(`0 0 ${soft}px ${Math.max(0, Math.floor(soft / 4))}px ${bcol}`);
    }
    el.style.boxShadow = arr.join(", ");

    // scroll
    el.style.overflowX = b.scroll.x ? "auto" : "hidden";
    el.style.overflowY = b.scroll.y ? "auto" : "hidden";

    // layout sizing (flex & common)
    const L = b.layout || {};
    el.style.flexGrow = L.grow || 0;
    el.style.flexShrink = L.shrink == null ? 1 : L.shrink;
    if (L.basis?.mode === "auto") el.style.flexBasis = "auto";
    else if (L.basis?.mode === "px")
      el.style.flexBasis = (L.basis.value || 0) + "px";
    else if (L.basis?.mode === "%")
      el.style.flexBasis = (L.basis.value || 0) + "%";
    else if (L.basis?.mode === "fill") {
      el.style.flexBasis = "0px";
      el.style.flexGrow = 1;
      el.style.flexShrink = 1;
    }

    el.style.alignSelf =
      L.alignSelf && L.alignSelf !== "auto" ? L.alignSelf : "";
    el.style.width = L.widthPx ? L.widthPx + "px" : "";

    // height options
    if (L.fullHeight) {
      el.style.minHeight = `calc(100vh - 160px)`;
    } // запас під тулбар/паддінги
    else if (L.fixedHeight) {
      el.style.minHeight = (L.fixedHeight | 0) + "px";
    } else {
      el.style.minHeight = L.minHeightPx ? L.minHeightPx + "px" : "";
    }

    // overlays
    const top = el.querySelector(":scope > .overlay.top");
    const bot = el.querySelector(":scope > .overlay.bottom");
    if (s.overlay.top.enable) {
      top.style.display = "block";
      top.style.height = (s.overlay.top.h || 0) + "px";
      top.style.background = `linear-gradient(180deg, ${hexToRgba(
        s.overlay.top.color,
        s.overlay.top.alpha
      )} 0%, rgba(0,0,0,0) 100%)`;
    } else top.style.display = "none";
    if (s.overlay.bottom.enable) {
      bot.style.display = "block";
      bot.style.height = (s.overlay.bottom.h || 0) + "px";
      bot.style.background = `linear-gradient(0deg, ${hexToRgba(
        s.overlay.bottom.color,
        s.overlay.bottom.alpha
      )} 0%, rgba(0,0,0,0) 100%)`;
    } else bot.style.display = "none";
  }

  function renderBlock(b) {
    const el = document.createElement("div");
    el.className = "st-block";
    el.dataset.id = b.id;

    const bgL = document.createElement("div");
    bgL.className = "bg-layer";
    el.appendChild(bgL);
    const topOv = document.createElement("div");
    topOv.className = "overlay top";
    el.appendChild(topOv);
    const botOv = document.createElement("div");
    botOv.className = "overlay bottom";
    el.appendChild(botOv);

    const tb = document.createElement("div");
    tb.className = "block-toolbar";
    const sizeChip = (() => {
      const m = b.layout.basis.mode;
      if (m === "px") return `${b.layout.basis.value || 0}px`;
      if (m === "%") return `${b.layout.basis.value || 0}%`;
      if (m === "fill") return "FILL";
      return "AUTO";
    })();
    const modeChip =
      b.display === "grid" ? "GRID" : b.dir === "row" ? "↔ ROW" : "↕ COL";
    tb.innerHTML = `<span class="chip">${modeChip}</span><span class="chip">${b.children.length} ⬚</span><span class="chip">${sizeChip}</span>`;
    el.appendChild(tb);

    b.children.forEach((c) => el.appendChild(renderBlock(c)));

    if (b.id === selectedId) {
      el.classList.add("selected");
      const rs = document.createElement("div");
      rs.className = "resizer right";
      el.appendChild(rs);
      const rb = document.createElement("div");
      rb.className = "resizer bottom";
      el.appendChild(rb);
      const rc = document.createElement("div");
      rc.className = "resizer corner";
      el.appendChild(rc);
      attachResizer(rs, el, b, "x");
      attachResizer(rb, el, b, "y");
      attachResizer(rc, el, b, "xy");
    }

    applyBlockStyles(el, b);
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      selectedId = b.id;
      updateInspector();
      render();
    });

    if (
      b.style.bg.type === "image" &&
      b.scroll.panEnable &&
      !b.scroll.bgFixed
    ) {
      el.addEventListener(
        "scroll",
        () => {
          const bgLayer = el.querySelector(":scope > .bg-layer");
          const maxX = Math.max(1, el.scrollWidth - el.clientWidth);
          const maxY = Math.max(1, el.scrollHeight - el.clientHeight);
          let px = "center",
            py = "center";
          if (
            (b.scroll.panDir === "x" || b.scroll.panDir === "xy") &&
            el.scrollWidth > el.clientWidth
          ) {
            const ratioX = el.scrollLeft / maxX;
            px = `${(ratioX * 100).toFixed(1)}%`;
          }
          if (
            (b.scroll.panDir === "y" || b.scroll.panDir === "xy") &&
            el.scrollHeight > el.clientHeight
          ) {
            const ratioY = el.scrollTop / maxY;
            py = `${(ratioY * 100).toFixed(1)}%`;
          }
          bgLayer.style.backgroundPosition = `${px} ${py}`;
        },
        { passive: true }
      );
    }
    return el;
  }

  function render() {
    canvas.innerHTML = "";
    rootBlocks.forEach((b) => canvas.appendChild(renderBlock(b)));
    renderTplList();
    renderBreadcrumbs();
  }

  // ===== Selection helpers
  function findById(list, id) {
    for (const b of list) {
      if (b.id === id) return b;
      const stack = [...b.children];
      while (stack.length) {
        const n = stack.shift();
        if (n.id === id) return n;
        stack.push(...n.children);
      }
    }
    return null;
  }
  function findParentAndIndex(id, list = rootBlocks) {
    for (let i = 0; i < list.length; i++) {
      const b = list[i];
      if (b.id === id) return { parent: null, index: i, arr: list };
      const res = deepFindParent(b, id);
      if (res) return res;
    }
    return null;
  }
  function deepFindParent(node, id) {
    for (let i = 0; i < node.children.length; i++) {
      const c = node.children[i];
      if (c.id === id) return { parent: node, index: i, arr: node.children };
      const r = deepFindParent(c, id);
      if (r) return r;
    }
    return null;
  }

  // ===== Actions
  function addRootBlock() {
    const b = createBlock({});
    rootBlocks.push(b);
    selectedId = b.id;
    render();
    updateInspector();
  }
  function addChildToSelected() {
    const sel = findById(rootBlocks, selectedId);
    if (!sel) return;
    const child = createBlock({
      dir: "column",
      style: { ...createBlock().style },
    });
    sel.children.push(child);
    selectedId = child.id;
    render();
    updateInspector();
  }
  function duplicateSelected() {
    const sel = findById(rootBlocks, selectedId);
    if (!sel) return;
    const { arr, index } = findParentAndIndex(selectedId) || {};
    const copy = cloneBlock(sel);
    copy.id = uid();
    if (arr) arr.splice(index + 1, 0, copy);
    else rootBlocks.push(copy);
    selectedId = copy.id;
    render();
    updateInspector();
  }
  function deleteSelected() {
    const pos = findParentAndIndex(selectedId);
    if (!pos) return;
    pos.arr.splice(pos.index, 1);
    selectedId = null;
    render();
    updateInspector();
  }

  // quick: insert two columns (sidebar + content)
  function insertTwoColumns() {
    const where = $("#dockWhere")?.value || "left";
    const w = Math.max(180, Number($("#dockWidth")?.value) || 280);
    const target =
      findById(rootBlocks, selectedId) ||
      (() => {
        addRootBlock();
        return findById(rootBlocks, selectedId);
      })();
    target.display = "flex";
    target.dir = "row";
    target.gap = 20;
    target.children = [
      createBlock({
        layout: {
          basis: {
            mode: "px",
            value: Math.max(180, Number($("#dockWidth").value) || 280),
            unit: "px",
          },
          grow: 0,
          shrink: 1,
          alignSelf: "stretch",
          minHeightPx: 260,
        },
        style: {
          ...createBlock().style,
          bg: { type: "color", color: "#111827", alpha: 0.85 },
        },
      }),
      createBlock({
        layout: {
          basis: { mode: "fill", value: 0, unit: "px" },
          grow: 1,
          shrink: 1,
          alignSelf: "stretch",
          minHeightPx: 260,
        },
        style: { ...createBlock().style },
      }),
    ];
    if (where === "right") target.children.reverse();
    render();
    updateInspector();
  }

  // ===== Toolbar & Inspector
  function renderBreadcrumbs() {
    const bc = $("#breadcrumbs");
    if (!selectedId) {
      bc.textContent = "Виберіть секцію…";
      $("#selLabel").textContent = "Немає вибору";
      return;
    }
    const path = [];
    (function dfs(list, chain) {
      for (const b of list) {
        const cc = [...chain, b];
        if (b.id === selectedId) {
          path.push(...cc);
          return true;
        }
        if (dfs(b.children, cc)) return true;
      }
      return false;
    })(rootBlocks, []);
    bc.innerHTML = path
      .map(
        (b, i) =>
          `<span class="small">${i ? "› " : ""}</span><a href="#" data-id="${
            b.id
          }" style="color:#93c5fd">Block(${
            b.display === "grid" ? "grid" : b.dir
          })</a>`
      )
      .join(" ");
    $$("#breadcrumbs a").forEach((a) =>
      a.addEventListener("click", (e) => {
        e.preventDefault();
        selectedId = a.dataset.id;
        render();
        updateInspector();
      })
    );
    $("#selLabel").textContent = `ID: ${selectedId}`;
  }

  const controls = {};
  function cacheControls() {
    [
      "display",
      "dir",
      "justify",
      "align",
      "gap",
      "padT",
      "padR",
      "padB",
      "padL",
      "maxw",
      "sizeMode",
      "sizeVal",
      "grow",
      "shrink",
      "alignSelf",
      "minH",
      "widthPx",
      "fullHeight",
      "fixedHeight",
      "dockWhere",
      "dockWidth",
      "gridCols",
      "gridGap",
    ].forEach((id) => (controls[id] = $(`#${id}`)));
    // + ще десятки інпутів з великого інспектора — залиш у себе як є (залишив сумісність)
    // Якщо у тебе вже є решта контролів — скрипт їх підхопить (дивись нижче в bindInputs).
  }

  function reflectDisplaySections(b) {
    $("#flexDirRow").style.display = b.display === "flex" ? "grid" : "none";
    $("#flexAlignRow").style.display = b.display === "flex" ? "grid" : "none";
    $("#gridSetup").style.display = b.display === "grid" ? "grid" : "none";
  }

  function updateInspector() {
    const b = findById(rootBlocks, selectedId);
    if (!b) return;
    controls.display.value = b.display;
    reflectDisplaySections(b);

    controls.dir.value = b.dir;
    controls.justify.value = b.justify;
    controls.align.value = b.align;
    controls.gap.value = b.gap;
    controls.padT.value = b.padding.t;
    controls.padR.value = b.padding.r;
    controls.padB.value = b.padding.b;
    controls.padL.value = b.padding.l;
    controls.maxw.value = b.maxWidth;

    controls.sizeMode.value = b.layout.basis.mode;
    controls.sizeVal.value = b.layout.basis.value || "";
    controls.grow.checked = !!b.layout.grow;
    controls.shrink.checked = !!b.layout.shrink;
    controls.alignSelf.value = b.layout.alignSelf || "auto";
    controls.minH.value = b.layout.minHeightPx || "";
    controls.widthPx.value = b.layout.widthPx || "";
    controls.fullHeight.checked = !!b.layout.fullHeight;
    controls.fixedHeight.value = b.layout.fixedHeight || "";

    controls.gridCols.value = b.grid?.cols ?? 2;
    controls.gridGap.value = b.grid?.gap ?? 16;
  }

  function attachResizer(handle, el, b, mode) {
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const startX = e.clientX,
        startY = e.clientY;
      const rect = el.getBoundingClientRect();
      const pinf = findParentAndIndex(b.id),
        parent = pinf?.parent;
      const parentDir = parent ? parent.dir : "row";
      const initBasis = { ...b.layout.basis };
      const initWidth = b.layout.widthPx || rect.width;
      const initMinH =
        b.layout.minHeightPx ||
        parseInt(getComputedStyle(el).minHeight) ||
        rect.height;
      function onMove(ev) {
        const dx = ev.clientX - startX,
          dy = ev.clientY - startY;
        if (mode.includes("x")) {
          if (parentDir === "row") {
            const newPx = clamp(
              (initBasis.mode === "px" ? initBasis.value : rect.width) + dx,
              0,
              4096
            );
            b.layout.basis = { mode: "px", value: newPx, unit: "px" };
            b.layout.grow = 0;
            b.layout.shrink = 1;
          } else {
            const newW = clamp(initWidth + dx, 0, 4096);
            b.layout.widthPx = newW;
          }
        }
        if (mode.includes("y")) {
          const newH = clamp(initMinH + dy, 0, 4096);
          b.layout.minHeightPx = newH;
        }
        render();
        updateInspector();
      }
      let keydownHandler = null;

      function bindInputs() {
        // …
        keydownHandler = (e) => {
          if (
            (e.key === "Delete" || e.key === "Backspace") &&
            !["INPUT", "TEXTAREA", "SELECT"].includes(
              document.activeElement.tagName
            )
          ) {
            e.preventDefault();
            deleteSelected();
          }
          if (e.key === "s" && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            $("#saveTpl")?.click();
          }
        };
        document.addEventListener("keydown", keydownHandler);
      }
      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    });
  }

  function bindInputs() {
    // базові
    controls.display.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.display = controls.display.value;
      reflectDisplaySections(b);
      render();
    });
    controls.dir.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.dir = controls.dir.value;
      render();
    });
    controls.justify.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.justify = controls.justify.value;
      render();
    });
    controls.align.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.align = controls.align.value;
      render();
    });
    controls.gap.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.gap = +controls.gap.value || 0;
      render();
    });

    ["padT", "padR", "padB", "padL"].forEach((k) =>
      controls[k].addEventListener("input", () => {
        const b = findById(rootBlocks, selectedId);
        if (!b) return;
        b.padding.t = +controls.padT.value || 0;
        b.padding.r = +controls.padR.value || 0;
        b.padding.b = +controls.padB.value || 0;
        b.padding.l = +controls.padL.value || 0;
        render();
      })
    );
    controls.maxw.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.maxWidth = controls.maxw.value;
      render();
    });

    // sizing
    controls.sizeMode.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      const m = controls.sizeMode.value;
      b.layout.basis.mode = m;
      if (m === "fill") {
        b.layout.grow = 1;
        b.layout.shrink = 1;
        b.layout.basis.value = 0;
      }
      render();
      updateInspector();
    });
    controls.sizeVal.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.basis.value = +controls.sizeVal.value || 0;
      render();
    });
    controls.grow.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.grow = controls.grow.checked ? 1 : 0;
      render();
    });
    controls.shrink.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.shrink = controls.shrink.checked ? 1 : 0;
      render();
    });
    controls.alignSelf.addEventListener("change", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.alignSelf = controls.alignSelf.value;
      render();
    });
    controls.minH.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.minHeightPx = +controls.minH.value || 0;
      render();
    });
    controls.widthPx.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.layout.widthPx = +controls.widthPx.value || 0;
      render();
    });

    // height toggles
    controls.fullHeight.addEventListener("change", () => {
      const L = findById(rootBlocks, selectedId);
      if (L.fullHeight) {
        el.style.minHeight = `calc(100vh - var(--header-h, 0px) - var(--safe-bottom, 0px) - 24px)`;
      } else if (L.fixedHeight) {
        el.style.minHeight = (L.fixedHeight | 0) + "px";
      } else {
        el.style.minHeight = L.minHeightPx ? L.minHeightPx + "px" : "";
      }

      render();
    });
    controls.fixedHeight.addEventListener("input", () => {
      const L = findById(rootBlocks, selectedId);
      if (L.fullHeight) {
        el.style.minHeight = `calc(100vh - var(--header-h, 0px) - var(--safe-bottom, 0px) - 24px)`;
      } else if (L.fixedHeight) {
        el.style.minHeight = (L.fixedHeight | 0) + "px";
      } else {
        el.style.minHeight = L.minHeightPx ? L.minHeightPx + "px" : "";
      }
      render();
    });

    // grid
    controls.gridCols.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.grid.cols = Math.max(1, +controls.gridCols.value || 2);
      render();
    });
    controls.gridGap.addEventListener("input", () => {
      const b = findById(rootBlocks, selectedId);
      if (!b) return;
      b.grid.gap = Math.max(0, +controls.gridGap.value || 0);
      render();
    });

    // hotkeys
    document.addEventListener("keydown", (e) => {
      if (
        (e.key === "Delete" || e.key === "Backspace") &&
        !["INPUT", "TEXTAREA", "SELECT"].includes(
          document.activeElement.tagName
        )
      ) {
        e.preventDefault();
        deleteSelected();
      }
      if (e.key === "s" && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        $("#saveTpl")?.click();
      }
    });
  }

  // ===== Templates (localStorage)
  const LS_KEY = "stbuilder.templates.v1";
  const loadTemplates = () => {
    try {
      return JSON.parse(localStorage.getItem(LS_KEY) || "[]");
    } catch {
      return [];
    }
  };
  const saveTemplates = (list) =>
    localStorage.setItem(LS_KEY, JSON.stringify(list));
  function saveCurrentAsTemplate() {
    const b = findById(rootBlocks, selectedId) || rootBlocks[0];
    if (!b) return alert("Немає секції для збереження");
    const name = $("#tplName")?.value || "Section",
      category = $("#tplCat")?.value || "section";
    const tpl = { id: uid(), name, category, payload: cloneBlock(b) };
    const all = loadTemplates();
    all.push(tpl);
    saveTemplates(all);
    renderTplList();
    alert("Збережено у локальні шаблони");
  }
  function renderTplList() {
    const wrap = $("#tplList");
    if (!wrap) return;
    wrap.innerHTML = "";
    const all = loadTemplates();
    all.forEach((t) => {
      const btn = document.createElement("button");
      btn.className = "tag";
      btn.textContent = `${t.category}: ${t.name}`;
      btn.addEventListener("click", () => {
        const blk = cloneBlock(t.payload);
        blk.id = uid();
        rootBlocks.push(blk);
        selectedId = blk.id;
        render();
        updateInspector();
      });
      wrap.appendChild(btn);
    });
  }
  function exportTemplates() {
    const data = JSON.stringify(loadTemplates(), null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "shiftTime_sections.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }
  async function importFromFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const arr = JSON.parse(text);
      if (!Array.isArray(arr)) throw new Error("Формат не підтримується");
      saveTemplates([...loadTemplates(), ...arr]);
      renderTplList();
      alert("Імпортовано шаблони");
    } catch (err) {
      alert("Помилка імпорту: " + err.message);
    } finally {
      e.target.value = "";
    }
  }

  // ===== Mount/Unmount (плагін API)
  function mount(_host) {
    host = _host;
    canvas =
      $("#canvas", host) ||
      (() => {
        // підстрахуємо, якщо html ще не патчений
        const wrap = document.createElement("div");
        wrap.id = "canvas";
        wrap.className = "canvas";
        host.appendChild(wrap);
        return wrap;
      })();
    // host — це кореневий елемент плагіна (де твій .st-app)
    InspectorDock.mount(host, {
      toolbarSelector: ".toolbar", // де показувати кнопку "Відкрити інспектор"
      headerVar: "--header-h", // змінна для відступу зверху
      sidebarSelector: ".sidebar", // твій лівий сайдбар
      collapsedClass: "sidebar-collapsed", // клас, який ставиш на body при згортанні сайдбару
      lsSideKey: "ui:insp:side",
      lsOpenKey: "ui:insp:open",
    });

    // toolbar
    $("#add-root", host).addEventListener("click", addRootBlock);
    $("#add-child", host).addEventListener("click", addChildToSelected);
    $("#insert-two", host).addEventListener("click", insertTwoColumns);
    $("#dup", host).addEventListener("click", duplicateSelected);
    $("#del", host).addEventListener("click", deleteSelected);
    $("#saveTpl", host)?.addEventListener("click", saveCurrentAsTemplate);
    $("#exportTpl", host)?.addEventListener("click", exportTemplates);
    $("#importFile", host)?.addEventListener("change", importFromFile);

    cacheControls();
    bindInputs();

    // демо блок
    const demo = createBlock({
      display: "flex",
      dir: "row",
      gap: 20,
      style: {
        ...createBlock().style,
        bg: {
          type: "gradient",
          gA: "#0f172a",
          gAalpha: 1,
          gB: "#1d4ed8",
          gBalpha: 0.6,
          angle: 135,
        },
      },
    });
    demo.children.push(
      createBlock({
        layout: {
          basis: { mode: "%", value: 40, unit: "%" },
          grow: 0,
          shrink: 1,
          alignSelf: "stretch",
          minHeightPx: 260,
        },
        style: {
          ...createBlock().style,
          bg: { type: "color", color: "#111827", alpha: 0.8 },
        },
      })
    );
    demo.children.push(
      createBlock({
        layout: {
          basis: { mode: "fill", value: 0, unit: "px" },
          grow: 1,
          shrink: 1,
          alignSelf: "stretch",
          minHeightPx: 260,
        },
        style: {
          ...createBlock().style,
          bg: {
            type: "image",
            url: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop",
            size: "cover",
            pos: "center",
            overlayColor: "#000",
            overlayAlpha: 0.35,
            gray: 0.3,
          },
        },
        padding: { t: 120, r: 24, b: 120, l: 24 },
        scroll: {
          x: false,
          y: true,
          panEnable: true,
          panDir: "y",
          bgFixed: false,
        },
      })
    );
    rootBlocks = [demo];
    selectedId = demo.id;
    render();
    updateInspector();
  }

  let keydownHandler = null; // оголоси поруч з іншими let на верху IIFE

  function unmount() {
    if (keydownHandler) {
      document.removeEventListener("keydown", keydownHandler);
      keydownHandler = null;
    }
    try {
      InspectorDock.unmount(host);
    } catch {}
    host = null;
    canvas = null;
    rootBlocks = [];
    selectedId = null;
  }

  window.__plugins = window.__plugins || {};
  window.__plugins["design"] = { mount, unmount };
})();

// ВСЕРЕДИНІ IIFE заміни свій unmount() на цей:
function unmount() {
  // зняти hotkeys (див. пункт 2)
  if (keydownHandler) {
    document.removeEventListener("keydown", keydownHandler);
    keydownHandler = null;
  }

  // прибрати докований інспектор і повернути контент назад
  try {
    InspectorDock.unmount(host);
  } catch {}

  host = null;
  canvas = null;
  rootBlocks = [];
  selectedId = null;
}
