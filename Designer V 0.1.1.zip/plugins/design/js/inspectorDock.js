(function (global) {
  const DEFAULTS = {
    toolbarSelector: ".toolbar",
    headerVar: "--header-h",
    sidebarSelector: ".sidebar",
    collapsedClass: "sidebar-collapsed",
    lsSideKey: "ui:insp:side", // 'left' | 'right'
    lsOpenKey: "ui:insp:open", // '1' | '0'
  };

  function qs(sel, root = document) {
    return root.querySelector(sel);
  }

  function readCssVar(name) {
    const v = getComputedStyle(document.documentElement)
      .getPropertyValue(name)
      .trim();
    return v || "0px";
  }

  function px(v) {
    return typeof v === "number" ? `${v}px` : v;
  }

  function getSidebarWidth(cfg) {
    const sb = qs(cfg.sidebarSelector);
    if (!sb) return 0;
    // реальна ширина, навіть коли position: fixed/sticky
    const rect = sb.getBoundingClientRect();
    // коли сайдбар згорнутий — повертаємо компактну ширину
    const collapsed = document.body.classList.contains(cfg.collapsedClass);
    if (collapsed) {
      // якщо у вас є змінна — використайте її; інакше беремо фактичну ширину
      // приклад: const v = readCssVar('--sidebar-w-compact')
      return Math.round(rect.width);
    }
    return Math.round(rect.width);
  }

  function createDockShell() {
    const portal = document.createElement("div");
    portal.className = "dock-panel";
    portal.id = "st-dock-inspector";

    // шапка
    const head = document.createElement("div");
    head.className = "dock-head";
    head.innerHTML = `
      <span class="badge">Інспектор секцій</span>
      <div style="flex:1"></div>
      <button class="hbtn" data-side>⇆ Перемістити</button>
      <button class="hbtn" data-close>Закрити</button>
    `;
    portal.appendChild(head);

    // тіло
    const body = document.createElement("div");
    body.className = "panel";
    portal.appendChild(body);

    return { portal, head, body };
  }

  function placeRight(portal, cfg) {
    portal.style.position = "fixed";
    portal.style.top = readCssVar(cfg.headerVar);
    portal.style.right = "0";
    portal.style.left = "";
    portal.classList.remove("left");
  }

  function placeLeft(portal, cfg) {
    portal.style.position = "fixed";
    portal.style.top = readCssVar(cfg.headerVar);
    portal.style.right = "";
    portal.classList.add("left");
    // відступ від лівого краю = ширина сайдбару
    portal.style.left = px(getSidebarWidth(cfg));
  }

  function addOpenButton(host, cfg, onOpen) {
    const bar = host.querySelector(cfg.toolbarSelector);
    if (!bar) return null;
    let btn = bar.querySelector("#open-inspector");
    if (!btn) {
      btn = document.createElement("button");
      btn.id = "open-inspector";
      btn.className = "btn ghost";
      btn.textContent = "Відкрити інспектор секцій";
      btn.addEventListener("click", onOpen);
      // вставимо перед підказкою (span.small), щоб була праворуч
      const tail = bar.querySelector(".small");
      bar.insertBefore(btn, tail || null);
    }
    return btn;
  }

  function removeOpenButton(host, cfg) {
    const bar = host.querySelector(cfg.toolbarSelector);
    const btn = bar && bar.querySelector("#open-inspector");
    if (btn) btn.remove();
  }

  function watchSidebarResize(cfg, portal) {
    // якщо переносимо вліво — треба оновлювати left при ресайзі
    function update() {
      if (portal.classList.contains("left")) {
        portal.style.left = px(getSidebarWidth(cfg));
      }
    }
    const ro = new ResizeObserver(update);
    const sb = qs(cfg.sidebarSelector);
    if (sb) ro.observe(sb);

    // слідкуємо за зміною класів body (згортання/розгортання)
    const mo = new MutationObserver(update);
    mo.observe(document.body, { attributes: true, attributeFilter: ["class"] });

    window.addEventListener("resize", update);
    return () => {
      try {
        ro.disconnect();
      } catch {}
      try {
        mo.disconnect();
      } catch {}
      window.removeEventListener("resize", update);
    };
  }

  function persistSide(cfg, side) {
    try {
      localStorage.setItem(cfg.lsSideKey, side);
    } catch {}
  }
  function restoreSide(cfg) {
    try {
      return localStorage.getItem(cfg.lsSideKey) || "right";
    } catch {
      return "right";
    }
  }
  function persistOpen(cfg, open) {
    try {
      localStorage.setItem(cfg.lsOpenKey, open ? "1" : "0");
    } catch {}
  }
  function restoreOpen(cfg) {
    try {
      return localStorage.getItem(cfg.lsOpenKey) !== "0";
    } catch {
      return true;
    }
  }

  const API = {
    mount(host, options = {}) {
      const cfg = Object.assign({}, DEFAULTS, options);
      const aside = host.querySelector("aside.right");
      if (!aside) {
        console.warn("[InspectorDock] aside.right not found");
        return;
      }
      const innerPanel = aside.querySelector(":scope > .panel");
      if (!innerPanel) {
        console.warn("[InspectorDock] .panel not found");
        return;
      }

      // якщо вже змонтовано — нічого не робимо
      if (host._inspectorDock?.portal?.isConnected) return;

      // створюємо оболонку
      const { portal, head, body } = createDockShell();

      // перенесемо ВСЕ наповнення з вашого .panel в body порталу
      while (innerPanel.firstChild) body.appendChild(innerPanel.firstChild);

      // поставимо портал у body (щоб перекривав контент і був незалежний від лейаута)
      document.body.appendChild(portal);

      // ховаємо оригінальний aside (щоб не займав місце)
      const placeholder = document.createElement("div");
      placeholder.style.display = "none";
      aside.appendChild(placeholder);
      aside.style.display = "none";

      // боковина: left/right
      const side = restoreSide(cfg); // 'left' | 'right'
      if (side === "left") placeLeft(portal, cfg);
      else placeRight(portal, cfg);

      // відкритий/закритий
      const initiallyOpen = restoreOpen(cfg);
      if (!initiallyOpen) {
        portal.style.display = "none";
        addOpenButton(host, cfg, () => {
          portal.style.display = "";
          removeOpenButton(host, cfg);
          persistOpen(cfg, true);
        });
      }

      // кнопки
      head.querySelector("[data-side]").addEventListener("click", () => {
        const nowLeft = portal.classList.contains("left");
        if (nowLeft) {
          placeRight(portal, cfg);
          persistSide(cfg, "right");
        } else {
          placeLeft(portal, cfg);
          persistSide(cfg, "left");
        }
      });

      head.querySelector("[data-close]").addEventListener("click", () => {
        portal.style.display = "none";
        persistOpen(cfg, false);
        addOpenButton(host, cfg, () => {
          portal.style.display = "";
          removeOpenButton(host, cfg);
          persistOpen(cfg, true);
        });
      });

      // тримаємо відступ від сайдбару (коли dock left)
      const stopWatch = watchSidebarResize(cfg, portal);

      // збережемо все для unmount
      host._inspectorDock = {
        cfg,
        portal,
        head,
        body,
        aside,
        placeholder,
        innerPanel,
        stopWatch,
      };
    },

    unmount(host) {
      const st = host?._inspectorDock;
      if (!st) return;
      try {
        st.stopWatch && st.stopWatch();

        // повертаємо контент назад у вихідний aside.panel
        while (st.body.firstChild)
          st.innerPanel.appendChild(st.body.firstChild);

        // показуємо aside
        st.aside.style.display = "";
        if (st.placeholder.parentNode === st.aside) st.placeholder.remove();

        // прибираємо портал
        st.portal.remove();

        // прибираємо кнопку "Відкрити"
        removeOpenButton(host, st.cfg);
      } catch (e) {
        console.warn("[InspectorDock] unmount error", e);
      } finally {
        host._inspectorDock = null;
      }
    },

    // опціонально: явні методи
    open(host) {
      const st = host?._inspectorDock;
      if (!st) return;
      st.portal.style.display = "";
      removeOpenButton(host, st.cfg);
      persistOpen(st.cfg, true);
    },
    close(host) {
      const st = host?._inspectorDock;
      if (!st) return;
      st.portal.style.display = "none";
      addOpenButton(host, st.cfg, () => API.open(host));
      persistOpen(st.cfg, false);
    },
    setSide(host, side) {
      const st = host?._inspectorDock;
      if (!st) return;
      if (side === "left") placeLeft(st.portal, st.cfg);
      else placeRight(st.portal, st.cfg);
      persistSide(st.cfg, side);
    },
  };

  global.InspectorDock = API;
})(window);
